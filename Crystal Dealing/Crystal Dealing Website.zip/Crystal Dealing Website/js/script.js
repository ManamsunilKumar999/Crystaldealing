document.addEventListener("DOMContentLoaded", function () {

    /* =========================
       IMAGE SLIDER
    ========================= */
    const slides = document.querySelectorAll(".about-slider img");
    let currentIndex = 0;

    if (slides.length > 0) {
        function showNextSlide() {
            slides.forEach(slide => slide.classList.remove("active"));
            slides[currentIndex].classList.add("active");
            currentIndex = (currentIndex + 1) % slides.length;
        }

        // Show first image immediately
        showNextSlide();

        // Change image every 3 seconds
        setInterval(showNextSlide, 3000);
    }

    /* =========================
       ABOUT BOX CLICK ACTIVE
    ========================= */
    const aboutBoxes = document.querySelectorAll(".about-box");

    aboutBoxes.forEach(box => {
        box.addEventListener("click", () => {
            aboutBoxes.forEach(b => b.classList.remove("active"));
            box.classList.add("active");
        });
    });

});

/* =========================
   MODAL FUNCTIONS
========================= */
function openModal(){
    document.getElementById("brochureModal").style.display = "flex";
}

function closeModal(){
    document.getElementById("brochureModal").style.display = "none";
}



