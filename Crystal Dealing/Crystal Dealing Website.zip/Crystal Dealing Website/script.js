/* ================= LANGUAGE TOGGLE ================= */
let currentLang = "en";

const translations = {
  en: {
    company_name: "Crystal Dealing & Trading",
    nav_home: "Home",
    nav_products: "Products",
    nav_about: "About",
    nav_contact: "Contact",
    lang_label: "Language",
    hero_title: "CRYSTAL DEALING & TRADING",
    hero_subtitle: "Strong Foundations. Trusted Steel. Timeless Quality.",
    btn_products: "Explore Products",
    btn_contact: "Contact Us",
    products_title: "Our Products",
    products_subtitle: "Premium quality steel products for every industry",
    p1: "TMT Bars", p2: "MS Rounds", p3: "MS Angles",
    p4: "MS Squares", p5: "MS Plates", p6: "Steel Pipes",
    why_title: "Why Crystal Dealing?",
    why_1: "✔ Trusted Steel Suppliers",
    why_2: "✔ Best Market Pricing",
    why_3: "✔ On-Time Delivery",
    why_4: "✔ Industrial Grade Quality",
    reach_text: "Feel free to reach us anytime – we're always here to help.",
    office: "Registered Office:",
    location: "Visakhapatnam, Andhra Pradesh",
    follow_us: "Follow Us",
    footer_company: "Company",
    footer_support: "Support",
    footer_faq: "FAQs",
    footer_privacy: "Privacy Policy"
  },
  ar: {
    company_name: "كريستال للتجارة والتوريد",
    nav_home: "الرئيسية",
    nav_products: "المنتجات",
    nav_about: "من نحن",
    nav_contact: "اتصل بنا",
    lang_label: "اللغة",
    hero_title: "كريستال للتجارة والتوريد",
    hero_subtitle: "أسس قوية. فولاذ موثوق. جودة دائمة.",
    btn_products: "استعرض المنتجات",
    btn_contact: "اتصل بنا",
    products_title: "منتجاتنا",
    products_subtitle: "منتجات فولاذية عالية الجودة لجميع الصناعات",
    p1: "قضبان TMT", p2: "دوائر MS", p3: "زوايا MS",
    p4: "مربعات MS", p5: "صفائح MS", p6: "أنابيب فولاذية",
    why_title: "لماذا كريستال؟",
    why_1: "✔ موردو فولاذ موثوقون",
    why_2: "✔ أفضل أسعار في السوق",
    why_3: "✔ تسليم في الوقت المحدد",
    why_4: "✔ جودة صناعية عالية",
    reach_text: "لا تتردد في التواصل معنا في أي وقت.",
    office: "المكتب المسجل:",
    location: "فيساخاباتنام، أندرا براديش",
    follow_us: "تابعنا",
    footer_company: "الشركة",
    footer_support: "الدعم",
    footer_faq: "الأسئلة الشائعة",
    footer_privacy: "سياسة الخصوصية"
  }
};
const { jsPDF } = window.jspdf;
///

/* ================= THEME (single source of truth) ================= */
function updateThemeIcons(isDark) {
  document.querySelectorAll('.theme-toggle i').forEach(i => {
    i.className = isDark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  });
}

function applyTheme(isDark) {
  document.body.classList.toggle('dark', isDark);
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  updateThemeIcons(isDark);
}

function toggleTheme() {
  applyTheme(!document.body.classList.contains('dark'));
}

// Apply saved theme immediately (before DOMContentLoaded avoids flash)
applyTheme(localStorage.getItem('theme') === 'dark');

/* ================= DOM READY ================= */
document.addEventListener("DOMContentLoaded", () => {

  /* ── Attach theme toggles (desktop + mobile) ── */
  document.querySelectorAll('.theme-toggle').forEach(btn => {
    btn.addEventListener('click', toggleTheme);
  });

  /* ── Language toggle (button) ── */
  const langBtn = document.getElementById("langToggle");
  if (langBtn) {
    langBtn.addEventListener("click", () => {
      currentLang = currentLang === "en" ? "ar" : "en";
      langBtn.innerText = currentLang === "en" ? "العربية" : "English";
      const langSelect = document.getElementById('langSelect');
      if (langSelect) langSelect.value = currentLang;
      applyTranslations();
    });
  }

  /* ── Language select (dropdown) ── */
  const langSelect = document.getElementById('langSelect');
  if (langSelect) {
    langSelect.value = currentLang;
    langSelect.addEventListener('change', () => {
      currentLang = langSelect.value;
      if (langBtn) langBtn.innerText = currentLang === 'en' ? 'العربية' : 'English';
      applyTranslations();
    });
  }

  /* ── Mobile language select ── */
  const langSelectMobile = document.getElementById('langSelectMobile');
  if (langSelectMobile) {
    langSelectMobile.value = currentLang;
    langSelectMobile.addEventListener('change', () => {
      currentLang = langSelectMobile.value;
      if (langBtn) langBtn.innerText = currentLang === 'en' ? 'العربية' : 'English';
      if (langSelect) langSelect.value = currentLang;
      applyTranslations();
    });
  }

  function applyTranslations() {
    document.querySelectorAll("[data-key]").forEach(el => {
      const val = translations[currentLang][el.dataset.key];
      if (val !== undefined) el.innerText = val;
    });
    document.documentElement.lang = currentLang;
    document.documentElement.dir  = currentLang === 'ar' ? 'rtl' : 'ltr';
  }

  /* ── Auto active menu link ── */
  const currentPage = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".menu a").forEach(link => {
    if (link.getAttribute("href") === currentPage) link.classList.add("active");
  });

  /* ── Mobile menu toggle + X close ── */
  const menuToggle = document.getElementById("menuToggle");
  const menu       = document.querySelector(".menu");

  if (menuToggle && menu) {
    menuToggle.addEventListener("click", (e) => {
      e.stopPropagation();
      const isOpen = menu.classList.toggle("show");
      menu.classList.toggle("active", isOpen);
      menuToggle.innerHTML = isOpen
        ? '<i class="fa-solid fa-xmark"></i>'
        : '<i class="fa-solid fa-bars"></i>';
    });

    // Close on link click
    document.querySelectorAll(".menu a").forEach(link => {
      link.addEventListener("click", () => {
        menu.classList.remove("show", "active");
        menuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
      });
    });

    // Close on outside click
    document.addEventListener("click", (e) => {
      if (!menu.contains(e.target) && !menuToggle.contains(e.target)) {
        menu.classList.remove("show", "active");
        menuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
      }
    });
  }

}); // end DOMContentLoaded

/* ================= CHATBOT ================= */
const chatbotMessages = [
  "👋 Hey there! Welcome to Crystal Dealing & Trading!",
  "💼 We provide premium industrial spare parts and steel trading solutions.",
  "🏢 With offices in Al Jubail, Saudi Arabia, we're here to serve you!",
  "⭐ Our products are trusted by businesses across the region.",
  "📦 From TMT Bars to Steel Pipes, we've got everything you need!",
  "🤝 Let's build a strong partnership together!",
  "💡 Need a solution? We're here to help!",
  "🚀 Quality products, reliable service, timeless trust!",
  "☎️ Ready to discuss your requirements?",
  "✅ Get in touch - we'd love to hear from you!"
];

const chatbotIcon              = document.getElementById("chatbotIcon");
const chatbotWindow            = document.getElementById("chatbotWindow");
const chatbotClose             = document.getElementById("chatbotClose");
const chatbotMessagesContainer = document.getElementById("chatbotMessages");
const chatbotWhatsappBtn       = document.getElementById("chatbotWhatsappBtn");
const chatbotInput             = document.getElementById("chatbotInput");
const chatbotSendBtn           = document.getElementById("chatbotSendBtn");

let chatbotOpened    = false;
let userMessageCount = 0;

const botReplies = [
  "Thanks for reaching out! 😊",
  "We'd love to help you! 🙌",
  "Great question! Let's chat! 💬",
  "Perfect! I'm here to assist! ✨",
  "Awesome! Let me help you! 🚀"
];

if (chatbotIcon) {
  chatbotIcon.addEventListener("click", () => {
    chatbotOpened = !chatbotOpened;
    chatbotWindow.classList.toggle("open", chatbotOpened);
    if (chatbotOpened && chatbotMessagesContainer.children.length === 0) {
      userMessageCount = 0;
      startChatbot();
    }
  });
}

if (chatbotClose) {
  chatbotClose.addEventListener("click", () => {
    chatbotWindow.classList.remove("open");
    chatbotOpened = false;
  });
}

function startChatbot() {
  for (let i = 0; i < 4; i++) {
    setTimeout(() => {
      addBotMessage(chatbotMessages[Math.floor(Math.random() * chatbotMessages.length)]);
    }, 500 + i * 1500);
  }
}

function addBotMessage(text, isHTML = false) {
  const el = document.createElement("div");
  el.className = "chatbot-message bot";
  if (isHTML) el.innerHTML = text; else el.textContent = text;
  chatbotMessagesContainer.appendChild(el);
  chatbotMessagesContainer.scrollTop = chatbotMessagesContainer.scrollHeight;
  return el;
}

function handleUserMessage() {
  const userMessage = chatbotInput.value.trim();
  if (!userMessage) return;

  userMessageCount++;
  const userEl = document.createElement("div");
  userEl.className = "chatbot-message user";
  userEl.textContent = userMessage;
  chatbotMessagesContainer.appendChild(userEl);
  chatbotMessagesContainer.scrollTop = chatbotMessagesContainer.scrollHeight;
  chatbotInput.value = "";

  setTimeout(() => {
    addBotMessage(botReplies[Math.floor(Math.random() * botReplies.length)]);
    if (userMessageCount >= 5) {
      setTimeout(() => {
        const el = addBotMessage('<i class="fa-brands fa-whatsapp"></i> Contact with us on WhatsApp', true);
        el.style.cursor = "pointer";
        el.addEventListener("click", redirectToWhatsApp);
      }, 1500);
    }
  }, 1000);
}

if (chatbotSendBtn) chatbotSendBtn.addEventListener("click", handleUserMessage);
if (chatbotInput)   chatbotInput.addEventListener("keypress", e => { if (e.key === "Enter") handleUserMessage(); });

function redirectToWhatsApp() {
  const msg = encodeURIComponent("Hi! I'm interested in your products and services. Can you help me?");
  window.open(`https://wa.me/966537621246?text=${msg}`, "_blank");
}

if (chatbotWhatsappBtn) chatbotWhatsappBtn.addEventListener("click", redirectToWhatsApp);

const menuToggle = document.getElementById("menuToggle");
const menu = document.getElementById("menu");

menuToggle.addEventListener("click", () => {
    menu.classList.toggle("active");
});
// const menuToggle = document.getElementById("menuToggle");
// const menu = document.getElementById("menu");
    // const products = [
//         { id: 1,  title: "Stainless Steel Perforated Sheets",     category: "specialized", imageFront: "Specialized Products/Stainless Steel Perforated Sheets.jpeg",      imageBack: "Specialized Products/Stainless Steel Perforated Sheets1.jpeg",  desc: "High-quality stainless steel perforated sheets for filtration, screening, and architectural applications. Available in various hole patterns and sizes.", features: ["Various hole patterns","Custom sizes available","Corrosion resistant","High strength","Easy to clean and maintain"], apps: "Chemical processing plants, architectural designs, machinery guards, filtration systems, decorative panels." },
//         { id: 2,  title: "Stainless Steel Wire Mesh (304 & 316)", category: "specialized", imageFront: "Specialized Products/Stainless Steel Wire Mesh.webp",                imageBack: "Specialized Products/Stainless Steel Wire Mesh1.jpeg",            desc: "Premium stainless steel wire mesh available in grades 304 & 316 with various weave patterns for industrial filtration.", features: ["304 & 316 grades","Various weave types","High temperature resistance","Custom sizes","Corrosion resistant"], apps: "Chemical processing, food industry, mining operations, pharmaceutical filtration, water treatment plants." },
//         { id: 3,  title: "PTFE Teflon Rods & Sheets",             category: "specialized", imageFront: "Specialized Products/PTFE Teflon Rods & Sheets.jpeg",               imageBack: "Specialized Products/PTFE Teflon Rods & Sheets1.jpeg",           desc: "PTFE Teflon materials offering excellent chemical resistance, low friction properties, and non-stick surface.", features: ["Chemical resistant","Low friction coefficient","Non-stick surface","High temperature tolerance","Electrical insulator"], apps: "Chemical processing equipment, food industry machinery, bearing applications, seals, gaskets, electrical insulation." },
//         { id: 4,  title: "Filters (Customized Fabrication)",      category: "specialized", imageFront: "Specialized Products/Filters(Customized Fabrication).webp",          imageBack: "Specialized Products/Filters(Customized Fabrication)1.jpeg",    desc: "Custom-designed filtration solutions tailored to specific industrial requirements with various media options.", features: ["Custom designs","Various media options","High efficiency","Durable construction","Easy maintenance"], apps: "Water treatment plants, chemical processing, pharmaceuticals manufacturing, food & beverage industry, oil & gas." },
//         { id: 5,  title: "SS SHIM (304 & 316)",                   category: "specialized", imageFront: "Specialized Products/SS Shim.jpeg",                                 imageBack: "Specialized Products/SS Shim1.jpeg",                             desc: "Stainless steel shim stock for precision spacing, alignment, and adjustment in industrial machinery.", features: ["Precision thickness","Corrosion resistant","Easy to cut and shape","Various grades","High strength"], apps: "Machinery alignment, automotive assembly, aerospace components, precision equipment, tool making." },
//         { id: 6,  title: "Motor Terminal Plates",                 category: "specialized", imageFront: "Specialized Products/Motor Terminal plates.jpg",                    imageBack: "Specialized Products/Motor Terminal Plates.jpeg",                desc: "Insulated terminal plates for electric motor connections, ensuring safe and reliable electrical installations.", features: ["Insulated design","Various sizes","Durable materials","Easy installation","Heat resistant"], apps: "Electric motor manufacturing, repair workshops, electrical installations, industrial equipment assembly." },
//         { id: 7,  title: "Hilam Rods & Sheets",                   category: "specialized", imageFront: "Specialized Products/Hilam Rods & sheets.jpg",                      imageBack: "Specialized Products/Hilam Rods & sheets1.jpg",                  desc: "Hilam rods and sheets for specialized industrial applications requiring specific material properties.", features: ["High strength","Custom sizes","Durable construction","Specialized applications","Corrosion resistant"], apps: "Specialized machinery components, industrial fabrication, tool making, specialized equipment." },
//         { id: 8,  title: "Container Seal Locks",                  category: "specialized", imageFront: "Specialized Products/Container Seals Locks.jpg",                    imageBack: "Specialized Products/Container Seals Locks1.jpeg",               desc: "High-security container seals for shipping and logistics to ensure cargo integrity during transit.", features: ["Tamper-evident design","ISO compliant","Unique numbering","Heavy-duty construction","Easy to apply"], apps: "Shipping containers, truck cargo security, logistics companies, warehouse management, cargo tracking." },
//         { id: 9,  title: "Gland Packing Rope",                    category: "specialized", imageFront: "Specialized Products/Gland Packing Rope.png",                       imageBack: "Specialized Products/Gland Packing Rope1.webp",                  desc: "Gland packing ropes for sealing applications in pumps, valves, and rotating equipment.", features: ["High temperature resistant","Chemical resistant","Flexible material","Long service life","Self-lubricating"], apps: "Pump sealing applications, valve stems, industrial equipment, fluid handling systems, marine applications." },
//         { id: 10, title: "Gasket Sheets",                         category: "specialized", imageFront: "Specialized Products/Gasket Sheets.webp",                           imageBack: "Specialized Products/Gasket Sheets1.jpeg",                       desc: "Various gasket sheet materials for sealing applications in industrial equipment and piping.", features: ["Various materials","Custom thickness","Pressure resistant","Chemical resistant","Temperature stable"], apps: "Pipe flanges, equipment covers, machinery seals, industrial piping systems, automotive gaskets." },
//         { id: 11, title: "Motor Fans",                            category: "specialized", imageFront: "Specialized Products/Motor Fans.jpeg",                              imageBack: "Specialized Products/Motor Fans1.jpeg",                          desc: "Industrial motor fans for cooling and ventilation applications in electrical equipment.", features: ["Various sizes","Balanced design","Efficient airflow","Durable construction","Low noise operation"], apps: "Motor cooling systems, ventilation equipment, industrial machinery, HVAC systems, electrical cabinets." },
//         { id: 12, title: "Motor Rewinding Materials",             category: "specialized", imageFront: "Specialized Products/Motor Rewinding Materials.jpeg",               imageBack: "Specialized Products/Motor Rewinding Materials1.jpeg",           desc: "Complete range of materials for motor rewinding and electrical repair applications.", features: ["High-quality insulation","Various wire gauges","Heat resistant","Durable","Easy to work with"], apps: "Electric motor repair, generator maintenance, transformer winding, electrical repairs, coil winding." },
//         { id: 13, title: "Bearings",                              category: "general",     imageFront: "General Products/Bearings.png",                                     imageBack: "General Products/Bearings1.jpg",                                 desc: "Various types of bearings for industrial, automotive, and mechanical applications.", features: ["Multiple types available","High load capacity","Smooth operation","Long service life","Precision made"], apps: "Machinery equipment, automotive industry, industrial equipment, appliances, conveyors, pumps." },
//         { id: 14, title: "Mechanical Seals (All Types)",          category: "general",     imageFront: "General Products/Mechanical Seals (All Types).jpg",                 imageBack: "General Products/Mechanical Seals (All Types)1.jpeg",            desc: "Complete range of mechanical seals for pumps, compressors, and rotating equipment.", features: ["Various designs","Leak-proof","High pressure rating","Long service life","Easy installation"], apps: "Pumps, compressors, mixers, agitators, industrial equipment, marine applications." },
//         { id: 15, title: "Hydraulic Seals",                       category: "general",     imageFront: "General Products/Hydraulic Seals.jpeg",                             imageBack: "General Products/Hydraulic Seals1.jpeg",                         desc: "Hydraulic seals for preventing leakage in hydraulic cylinders and systems.", features: ["High pressure rating","Wear resistant","Various materials","Standard sizes","Temperature resistant"], apps: "Hydraulic cylinders, hydraulic systems, construction equipment, manufacturing machinery." },
//         { id: 16, title: "Oil Seals",                             category: "general",     imageFront: "General Products/Oil Seals.jpg",                                    imageBack: "General Products/Oil Seals1.jpeg",                               desc: "Oil seals for preventing leakage in rotating shafts and mechanical equipment.", features: ["Heat resistant","Chemical resistant","Various sizes","Flexible design","Long service life"], apps: "Automotive engines, industrial machinery, gearboxes, rotating equipment, pumps." },
//         { id: 17, title: "E-Clips (Internal & External)",         category: "general",     imageFront: "General Products/E-Clips (Internal & External).jpeg",               imageBack: "General Products/E-Clips (Internal & External)1.jpeg",          desc: "E-clips for securing components on shafts and pins in mechanical assemblies.", features: ["Internal & external types","Various sizes","Easy installation","Secure retention","Durable"], apps: "Shaft assemblies, automotive components, machinery, industrial equipment, mechanical linkages." },
//         { id: 18, title: "O Rings",                               category: "general",     imageFront: "General Products/O Rings.jpeg",                                     imageBack: "General Products/O Rings1.jpeg",                                 desc: "O-rings for sealing applications in hydraulic, pneumatic, and fluid systems.", features: ["Various materials","Standard sizes","Chemical resistant","Temperature resistant","Pressure rated"], apps: "Hydraulic systems, pneumatic systems, plumbing, automotive, pumps, valves." },
//         { id: 19, title: "Belts (All Types)",                     category: "general",     imageFront: "General Products/Belts (All Types).jpeg",                           imageBack: "General Products/Belts (All Types)1.jpeg",                       desc: "Industrial belts for power transmission and conveying applications.", features: ["V-belts, timing belts","Various sizes","High strength","Wear resistant","Flexible"], apps: "Conveyor systems, power transmission, machinery, automotive, industrial equipment." },
//         { id: 20, title: "PTFE Fabrics",                          category: "general",     imageFront: "General Products/ptfe-fabrics.jpeg",                                imageBack: "General Products/PTFE Fabrics1.jpeg",                            desc: "PTFE fabrics for industrial applications requiring chemical resistance.", features: ["Chemical resistant","Non-stick","High temperature tolerance","Durable","Flexible"], apps: "Conveyor belts, release sheets, industrial linings, packaging, filtration media." },
//         { id: 21, title: "Springs",                               category: "general",     imageFront: "General Products/Springs.webp",                                     imageBack: "General Products/Springs1.jpg",                                  desc: "Various types of springs including tension, compression, and torsion.", features: ["Multiple types","Various sizes","High quality steel","Precise calibration","Durable"], apps: "Automotive suspension, machinery, valves, industrial equipment, appliances, tools." },
//         { id: 22, title: "Sprockets",                             category: "general",     imageFront: "General Products/Sprockets.jpeg",                                   imageBack: "General Products/Sprockets1.jpeg",                               desc: "Sprockets for chain drive systems in industrial and mechanical applications.", features: ["Various pitches","Precision made","Durable materials","Standard sizes","Heat treated"], apps: "Conveyor systems, machinery drives, automotive, power transmission, industrial equipment." },
//         { id: 23, title: "Pulleys",                               category: "general",     imageFront: "General Products/Pulleys.jpeg",                                     imageBack: "General Products/Pulleys1.jpeg",                                 desc: "Pulleys for belt drive systems and mechanical power transmission.", features: ["Various sizes","Grooved design","Balanced construction","Durable materials","Precision bored"], apps: "Power transmission, conveyor systems, machinery, automotive, ventilation systems." },
//         { id: 24, title: "Spiders",                               category: "general",     imageFront: "General Products/Spiders.png",                                      imageBack: "General Products/Spiders1.webp",                                 desc: "Spider couplings for connecting shafts in mechanical power transmission.", features: ["Flexible design","High torque capacity","Easy installation","Vibration damping","Maintenance free"], apps: "Motor-to-pump connections, conveyor systems, machinery, generator connections." },
//         { id: 25, title: "Couplings",                             category: "general",     imageFront: "General Products/Couplings.jpg",                                    imageBack: "General Products/Couplings1.jpg",                                desc: "Shaft couplings for connecting rotating equipment and power transmission.", features: ["Various types","Flexible design","High torque capacity","Easy installation","Precision alignment"], apps: "Motor-to-pump connections, conveyor systems, machinery, generators, compressors." },
//         { id: 26, title: "Spiral Wound Gasket",                   category: "general",     imageFront: "General Products/Spiral Wond Gasket.jpeg",                          imageBack: "General Products/Spiral Wond Gasket1.jpeg",                      desc: "Spiral wound gaskets for high-pressure and high-temperature sealing.", features: ["High pressure rating","Temperature resistant","Flexible design","Reliable sealing","Various sizes"], apps: "Pipe flanges, heat exchangers, pressure vessels, industrial equipment, boiler systems." },
//         { id: 27, title: "Silicon Rubber Sheet",                  category: "general",     imageFront: "General Products/Silicon Rubber Sheet.webp",                        imageBack: "General Products/Silicon Rubber Sheet1.jpg",                     desc: "Silicon rubber sheets for high-temperature sealing and insulation.", features: ["High temperature resistant","Flexible","Weather resistant","Good insulation","Chemical resistant"], apps: "Gaskets, seals, insulation pads, electrical applications, high-temperature sealing." },
//         { id: 28, title: "Rubber Blanket",                        category: "general",     imageFront: "General Products/Rubber Blanket.jpeg",                              imageBack: "General Products/Rubber Blanket1.jpeg",                          desc: "Industrial rubber blankets for protection, insulation, and lining.", features: ["Durable","Flexible","Abrasion resistant","Various thicknesses","Weather proof"], apps: "Protective covers, linings, insulation, industrial applications, construction sites." },
//         { id: 29, title: "Rubber Cork Sheet",                     category: "general",     imageFront: "General Products/Rubber Cork Sheet.jpeg",                           imageBack: "General Products/Rubber Cork Sheet1.jpeg",                       desc: "Rubber cork sheets for vibration damping and sealing applications.", features: ["Vibration damping","Good sealing","Flexible","Durable","Compressible"], apps: "Gaskets, vibration isolation pads, sealing applications, machinery mounts." },
//         { id: 30, title: "Asbestos & Non Asbestos Sheets",        category: "general",     imageFront: "General Products/Asbetos & Non Asbestos Sheets.jpeg",               imageBack: "General Products/Asbetos & Non Asbestos Sheets1.jpeg",          desc: "Asbestos and non-asbestos sheets for high-temperature sealing.", features: ["High temperature resistant","Good sealing","Various grades","Custom sizes","Pressure resistant"], apps: "High-temperature gaskets, boiler seals, industrial equipment, furnace doors." },
//         { id: 31, title: "Asbestos Rope",                         category: "general",     imageFront: "General Products/Asbestos Rope.webp",                               imageBack: "General Products/Asbestos Rope1.jpeg",                           desc: "Asbestos ropes for high-temperature sealing and insulation.", features: ["High temperature resistant","Flexible","Good sealing","Various diameters","Easy to install"], apps: "Boiler seals, furnace doors, high-temperature applications, kiln doors." },
//         { id: 32, title: "Round Asbestos Rope",                   category: "general",     imageFront: "General Products/Round Asbestos Rope.webp",                         imageBack: "General Products/Round Asbestos Rope1.jpeg",                     desc: "Round asbestos ropes for specialized high-temperature sealing.", features: ["Round profile","High temperature resistant","Flexible","Good sealing","Various sizes"], apps: "Specialized high-temperature seals, furnace applications, specialized industrial sealing." },
//         { id: 33, title: "Adhesive Tapes",                        category: "general",     imageFront: "General Products/Adhesive Tapes.jpeg",                              imageBack: "General Products/Adhesive Tapes (Single & Double Sheet)1.jpeg", desc: "Single and double-sided adhesive tapes for industrial and packaging applications.", features: ["Strong adhesion","Various widths","Temperature resistant","Water resistant"], apps: "Packaging, mounting, sealing, electrical insulation, industrial applications." },
//         { id: 34, title: "PTFE Teflon Tape",                      category: "general",     imageFront: "General Products/PTFE Telfon Tape.jpeg",                            imageBack: "General Products/PTFE Telfon Tape1.jpeg",                        desc: "PTFE Teflon tape for sealing pipe threads and threaded connections.", features: ["Chemical resistant","Non-stick","High temperature tolerant","Easy to apply"], apps: "Pipe threading, plumbing, hydraulic connections, industrial piping." },
//         { id: 35, title: "Fiber Tape Roll",                       category: "general",     imageFront: "General Products/Fiber Tape Roll.jpeg",                             imageBack: "General Products/Fiber Tape Roll1.jpeg",                         desc: "Fiber tape rolls for packaging, sealing, and reinforcement applications.", features: ["High strength","Water resistant","Various widths","Easy to tear"], apps: "Packaging, carton sealing, reinforcement, industrial applications." },
//         { id: 36, title: "HDPE / Nylon Rod",                      category: "general",     imageFront: "General Products/HDPE or Nylon Rod.jpeg",                           imageBack: "General Products/HDPE or Nylon Rod1.jpeg",                       desc: "HDPE and nylon rods for machining custom components and industrial applications.", features: ["Easy to machine","Chemical resistant","Various diameters","Durable"], apps: "Machined components, bearings, bushings, industrial parts." },
//         { id: 37, title: "Doctor Blades",                         category: "general",     imageFront: "General Products/Doctor Blades.jpeg",                               imageBack: "General Products/Doctor Blades1.jpeg",                           desc: "Doctor blades for coating, printing, and material handling applications.", features: ["Precise edge","Wear resistant","Various materials","Custom sizes"], apps: "Printing industry, coating applications, material handling." },
//         { id: 38, title: "PTFE Plastic",                          category: "general",     imageFront: "General Products/ptfe-fabrics.jpeg",                                imageBack: "General Products/PTFE Fabrics1.jpeg",                            desc: "PTFE Teflon plastic materials with and without adhesive backing.", features: ["Chemical resistant","Non-stick","Adhesive options","Various thicknesses"], apps: "Release sheets, linings, protective covers, industrial applications." },
//         { id: 39, title: "Stainless Steel Rods",                  category: "general",     imageFront: "General Products/Stainless Steel Rods.jpg",                         imageBack: "General Products/Stainless Steel Rods1.jpg",                     desc: "Stainless steel rods for machining, fabrication, and construction applications.", features: ["Various grades","Different diameters","Corrosion resistant","High strength"], apps: "Machining, fabrication, construction, industrial components." },
//         { id: 40, title: "Brass Round Rods",                      category: "general",     imageFront: "General Products/Brass Round Rods.jpg",                             imageBack: "General Products/Brass Round Rods1.webp",                        desc: "Brass round rods for machining, decorative, and electrical applications.", features: ["Easy to machine","Good conductivity","Corrosion resistant","Various diameters"], apps: "Machined components, decorative items, electrical applications." },
//         { id: 41, title: "Copper Rods",                           category: "general",     imageFront: "General Products/Copper Rods.jpeg",                                 imageBack: "General Products/Copper Rods1.jpeg",                             desc: "Copper rods for electrical, plumbing, and industrial applications.", features: ["Excellent conductivity","Corrosion resistant","Various diameters","Easy to work with"], apps: "Electrical applications, plumbing, heat exchangers, industrial uses." },
//         { id: 42, title: "Glass Tubes",                           category: "general",     imageFront: "General Products/Glass Tubes.jpeg",                                 imageBack: "General Products/Glass Tubes1.jpeg",                             desc: "Glass tubes for laboratory, industrial, and specialty applications.", features: ["Chemically inert","Transparent","Various diameters","Heat resistant"], apps: "Laboratory equipment, industrial viewing ports, specialty applications." },
//         { id: 43, title: "Pneumatic Tube",                        category: "general",     imageFront: "General Products/Pneumatic Tube.jpeg",                              imageBack: "General Products/Pneumatic Tube1.jpeg",                          desc: "Pneumatic tubes for air systems, automation, and material handling.", features: ["Flexible","Pressure resistant","Various sizes","Durable"], apps: "Pneumatic systems, automation, material handling, air lines." },
//         { id: 44, title: "Mica Sheet Flexible",                   category: "general",     imageFront: "General Products/Mica Sheet Flexible.jpeg",                         imageBack: "General Products/Mica Sheet Flexible1.jpeg",                     desc: "Flexible mica sheets for electrical insulation and high-temperature applications.", features: ["High temperature resistant","Excellent insulator","Flexible","Various thicknesses"], apps: "Electrical insulation, heating elements, high-temperature applications." },
//         { id: 45, title: "Mica Paper Roll",                       category: "general",     imageFront: "General Products/Mica Paper Roll.jpeg",                             imageBack: "General Products/Mica Paper Roll1.jpeg",                         desc: "Mica paper rolls for electrical insulation and specialty applications.", features: ["Excellent insulator","High temperature resistant","Flexible","Roll form"], apps: "Electrical insulation, specialty applications, high-temperature uses." },
//         { id: 46, title: "Clear / PVC Rolls",                     category: "general",     imageFront: "General Products/pvc-roll.jpg",                                     imageBack: "General Products/Adhesive Tapes (Single & Double Sheet)1.jpeg", desc: "Clear and PVC rolls for packaging, protection, and industrial applications.", features: ["Transparent options","Various thicknesses","Flexible","Durable"], apps: "Packaging, protective covers, industrial applications, displays." },
//         { id: 47, title: "Grease Fittings",                       category: "general",     imageFront: "General Products/Grease Fittings.jpg",                              imageBack: "General Products/Grease Fittings1.jpeg",                         desc: "Grease fittings for lubrication points in machinery and equipment.", features: ["Various types","Standard threads","Durable construction","Easy to install"], apps: "Machinery lubrication, automotive, industrial equipment, bearings." },
//         { id: 48, title: "Pneumatic Fittings",                    category: "general",     imageFront: "General Products/Pneumatic Fittings.jpeg",                          imageBack: "General Products/Pneumatic Fittings1.jpeg",                      desc: "Pneumatic fittings for air systems, automation, and pneumatic equipment.", features: ["Various types","Quick connect options","Pressure rated","Durable materials"], apps: "Pneumatic systems, automation, air lines, industrial equipment." }
//     ];

//     const grid        = document.getElementById('productGrid');
//     const searchInput = document.getElementById('searchInput');
//     const searchStats = document.getElementById('searchStats');
//     const modal       = document.getElementById('productModal');

//     let currentFilter      = 'all';
//     let currentSearchTerm  = '';
//     let currentProduct     = null;
//     let currentProductUrl  = "";

//     document.addEventListener('DOMContentLoaded', function () {
//         renderProducts();
//         setupEventListeners();
//     });

//     function setupEventListeners() {
//         document.querySelectorAll('.filter-btn').forEach(btn => {
//             btn.addEventListener('click', function () {
//                 document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
//                 this.classList.add('active');
//                 currentFilter = this.getAttribute('data-filter');
//                 const sectionTitle = document.querySelector('.section-title');
//                 if      (currentFilter === 'all')         sectionTitle.innerText = 'Industrial Products';
//                 else if (currentFilter === 'specialized') sectionTitle.innerText = 'Specialized Products';
//                 else if (currentFilter === 'general')     sectionTitle.innerText = 'General Products';
//                 renderProducts();
//             });
//         });
//         searchInput.addEventListener('input', e => {
//             currentSearchTerm = e.target.value.toLowerCase().trim();
//             renderProducts();
//         });
//         searchInput.addEventListener('keydown', e => {
//             if (e.key === 'Escape') { searchInput.value = ''; currentSearchTerm = ''; renderProducts(); }
//         });
//     }

//     function renderProducts() {
//         let filtered = products.filter(p => {
//             const catMatch    = currentFilter === 'all' || p.category === currentFilter;
//             const searchMatch = currentSearchTerm === '' ||
//                 p.title.toLowerCase().includes(currentSearchTerm) ||
//                 p.desc.toLowerCase().includes(currentSearchTerm) ||
//                 p.features.some(f => f.toLowerCase().includes(currentSearchTerm)) ||
//                 p.apps.toLowerCase().includes(currentSearchTerm);
//             return catMatch && searchMatch;
//         });
//         updateSearchStats(filtered.length);
//         if (filtered.length === 0) displayNoProductsMessage();
//         else displayProducts(filtered);
//     }

//     function updateSearchStats(count) {
//         let msg = currentSearchTerm
//             ? (count === 0 ? `No products for "${currentSearchTerm}"` : `Found ${count} product${count !== 1 ? 's' : ''} for "${currentSearchTerm}"`)
//             : `Showing ${count} product${count !== 1 ? 's' : ''}`;
//         searchStats.innerText = msg;
//         searchStats.style.color = (count === 0 && currentSearchTerm) ? '#dc3545' : '#6c757d';
//     }

//     function displayNoProductsMessage() {
//         grid.innerHTML = `<div class="no-products-message">
//             <i class="fas fa-box-open" style="font-size:3rem; opacity:0.4;"></i>
//             <h3 style="margin:15px 0 5px;">No Products Found</h3>
//             <p style="color:#6c757d;">"${currentSearchTerm}" – try another keyword</p>
//             <button class="btn-discover" style="margin:25px auto 0;" onclick="clearSearch()">Clear Search</button>
//         </div>`;
//     }

//     function displayProducts(items) {
//         let html = '';
//         items.forEach(p => {
//             const catClass = p.category === 'specialized' ? 'cat-spec' : 'cat-gen';
//             const catName  = p.category === 'specialized' ? 'Specialized' : 'General';
//             const fallback = `https://via.placeholder.com/400x300/0f2e53/ffffff?text=${encodeURIComponent(p.title.substring(0, 15))}`;
//             html += `<div class="product-card" onclick="openModal(${p.id})">
//                 <img src="${p.imageFront}" class="card-image" alt="${p.title}" loading="lazy" onerror="this.onerror=null;this.src='${fallback}'">
//                 <div class="card-body">
//                     <span class="card-category ${catClass}">${catName}</span>
//                     <h3 class="card-title">${p.title}</h3>
//                     <p class="card-text">${p.desc}</p>
//                     <button class="btn-discover" onclick="event.stopPropagation();openModal(${p.id})">View Details</button>
//                 </div>
//             </div>`;
//         });
//         grid.innerHTML = html;
//     }

//     window.clearSearch = function () {
//         searchInput.value = ''; currentSearchTerm = '';
//         document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
//         document.querySelector('.filter-btn[data-filter="all"]').classList.add('active');
//         currentFilter = 'all';
//         document.querySelector('.section-title').innerText = 'Industrial Products';
//         renderProducts();
//     };

//     window.requestQuote = function () {
//         if (!currentProduct) return;
//         window.location.href = `contact.html?product=${encodeURIComponent(currentProduct.title)}`;
//     };

//     window.openModal = function (id) {
//         currentProduct = products.find(p => p.id === id);
//         if (!currentProduct) return;
//         document.getElementById('modalTitle').innerText   = currentProduct.title;
//         document.getElementById('modalTag').innerText     = currentProduct.category.toUpperCase();
//         document.getElementById('modalDesc').innerText    = currentProduct.desc;
//         document.getElementById('modalApps').innerText    = currentProduct.apps;
//         const featureList = document.getElementById('modalFeatures');
//         featureList.innerHTML = '';
//         currentProduct.features.forEach(f => { let li = document.createElement('li'); li.innerText = f; featureList.appendChild(li); });
//         const imgFront = document.getElementById('modalImgFront');
//         const imgBack = document.getElementById('modalImgBack');
//         const fbFront  = `https://via.placeholder.com/700x520/0f2e53/ffffff?text=${encodeURIComponent(currentProduct.title.substring(0, 20))}`;
//         imgFront.src = currentProduct.imageFront + "?t=" + Date.now();
//         imgBack.src = currentProduct.imageBack + "?t=" + Date.now();
//         imgFront.onerror = function () { this.src = fbFront; };
//         const baseUrl = window.location.href.split('?')[0];
//         currentProductUrl = `${baseUrl}?product_id=${currentProduct.id}`;
//         const encoded = encodeURIComponent(currentProductUrl);
//         const titleEnc = encodeURIComponent(currentProduct.title);
//         document.getElementById('shareWa').href   = `https://api.whatsapp.com/send?text=${titleEnc}%0A${encoded}`;
//         document.getElementById('shareMail').href = `mailto:?subject=${titleEnc}&body=Check product: ${currentProductUrl}`;
//         document.getElementById('shareFb').href   = `https://www.facebook.com/sharer/sharer.php?u=${encoded}`;
//         modal.classList.add('open');
//         document.body.style.overflow = 'hidden';
//     };

//     window.closeModal = function () {
//         modal.classList.remove('open');
//         document.body.style.overflow = 'auto';
//     };

//     window.onclick = function (e) { if (e.target == modal) closeModal(); };

//     async function getBase64ImageSafe(imgUrl) {
//         try {
//             const response = await fetch(imgUrl, { mode: 'cors', cache: 'reload' });
//             if (!response.ok) throw new Error('fetch failed');
//             const blob = await response.blob();
//             return new Promise(resolve => {
//                 const reader = new FileReader();
//                 reader.onloadend = () => resolve(reader.result);
//                 reader.onerror  = () => resolve(null);
//                 reader.readAsDataURL(blob);
//             });
//         } catch (e) { return null; }
//     }

//     window.downloadProductPDF = async function () {
//         if (!currentProduct) return;
//         const btn = document.getElementById('pdfBtn');
//         const original = btn.innerHTML;
//         btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
//         const { jsPDF } = window.jspdf;
//         const doc = new jsPDF();
//         const margin = 20, pw = doc.internal.pageSize.getWidth(), cw = pw - margin * 2;
//         let y = 20;
//         try {
//             let imgData = null;
//             try { imgData = await getBase64ImageSafe(currentProduct.imageFront); } catch (e) {}
//             doc.setFontSize(22).setTextColor(15, 46, 83).text(currentProduct.title, margin, y); y += 12;
//             doc.setFontSize(12).setTextColor(220, 53, 69).text(`Category: ${currentProduct.category.toUpperCase()}`, margin, y); y += 15;
//             if (imgData) {
//                 try {
//                     const props = doc.getImageProperties(imgData);
//                     let imgW = cw, imgH = (props.height * imgW) / props.width;
//                     const maxH = 80;
//                     if (imgH > maxH) { imgH = maxH; imgW = (props.width * maxH) / props.height; const xOff = margin + (cw - imgW) / 2; doc.addImage(imgData, 'JPEG', xOff, y, imgW, imgH); }
//                     else { doc.addImage(imgData, 'JPEG', margin, y, imgW, imgH); }
//                     y += imgH + 12;
//                 } catch (e) { doc.setFontSize(10).setTextColor(150).text('(image format error)', margin, y); y += 10; }
//             } else { doc.setFontSize(10).setTextColor(150).text('(product image not available)', margin, y); y += 10; }
//             doc.setFontSize(14).setTextColor(0, 0, 0).text('Description:', margin, y); y += 8;
//             doc.setFontSize(11).setTextColor(60, 60, 60);
//             let descLines = doc.splitTextToSize(currentProduct.desc, cw);
//             doc.text(descLines, margin, y); y += (descLines.length * 5) + 10;
//             if (y > 230) { doc.addPage(); y = 20; }
//             doc.setFontSize(14).text('Key Features:', margin, y); y += 8;
//             doc.setFontSize(11);
//             currentProduct.features.forEach(f => { if (y > 270) { doc.addPage(); y = 20; } doc.text(`• ${f}`, margin, y); y += 6; });
//             y += 6;
//             if (y > 240) { doc.addPage(); y = 20; }
//             doc.setFontSize(14).text('Applications:', margin, y); y += 7;
//             let appLines = doc.splitTextToSize(currentProduct.apps, cw);
//             doc.setFontSize(11).text(appLines, margin, y);
//             for (let i = 1; i <= doc.internal.getNumberOfPages(); i++) {
//                 doc.setPage(i).setFontSize(9).setTextColor(150).text(`Page ${i} of ${doc.internal.getNumberOfPages()} – Crystal Dealing`, margin, doc.internal.pageSize.getHeight() - 10);
//             }
//             doc.save(`${currentProduct.title.replace(/\s+/g, '_')}_Specs.pdf`);
//         } catch (error) { showToast('PDF generation error, please try again'); console.error(error); }
//         finally { btn.innerHTML = original; }
//     };

//     function showToast(msg) {
//         let toast = document.getElementById('toast-msg');
//         toast.innerText = msg; toast.style.display = 'block';
//         setTimeout(() => toast.style.display = 'none', 2800);
//     }
//     window.copyLink = function () {
//         if (!currentProductUrl) return;
//         navigator.clipboard.writeText(currentProductUrl).then(() => showToast('✅ Link copied!')).catch(() => showToast('⚠️ Copy failed'));
//     };
//     window.shareToInsta = function (e) {
//         e.preventDefault();
//         if (!currentProductUrl) return;
//         navigator.clipboard.writeText(currentProductUrl).then(() => {
//             showToast('🔗 Link copied! Opening Instagram...');
//             setTimeout(() => window.open('https://instagram.com', '_blank'), 1000);
//         }).catch(() => showToast('Failed to copy'));
//     };
// document.addEventListener("click", function(e){

//     const flipCard = document.getElementById("flipCard");

//     if(flipCard && e.target.closest("#flipCard")){
//         flipCard.classList.toggle("flipped");
//     }

// });